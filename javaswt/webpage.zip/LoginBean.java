
public class LoginBean{
    public int Sessionid;
    public String Username;
    public String Password;

    public LoginBean(){

    }

	public int getSessionid() {
		return this.Sessionid;
	}

	public void setSessionid(int sessionid) {
		this.Sessionid = sessionid;
	}

	public String getUsername() {
		return this.Username;
	}

	public void setUsername(String username) {
		this.Username = username;
	}

	public String getPassword() {
		return this.Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}








}
